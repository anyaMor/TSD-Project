﻿using Microsoft.EntityFrameworkCore;

namespace FluidWrite.Models
{
    public class FluidWriteContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Document> Documents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=fluidWrite.db");
        }
    }
}