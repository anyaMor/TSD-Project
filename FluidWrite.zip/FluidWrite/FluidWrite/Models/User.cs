﻿using System.Collections.Generic;

namespace FluidWrite.Models
{
    public class User
    {
        public int Id { get; set; }

        public string User_name { get; set; }
        public string User_password { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public ICollection<Document> Documents { get; set; }
    }
}
