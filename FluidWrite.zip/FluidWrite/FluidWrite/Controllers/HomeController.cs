﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FluidWrite.Models;

namespace FluidWrite.Controllers
{
    public class HomeController : Controller
    {
        const string Dir = "../FluidWriteFiles/";

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Rename(string operation)
        {
            if (operation.Equals("Rename Text"))
            {
                DeleteText(Request.Form["oldTitle"]);
                saveText(Request.Form["title"], Request.Form["text"]);
                return RedirectToAction("MyDocuments");
            }
            loadText(Request.Form["titleLoad"]);
            return View();
        }

        public IActionResult MyDocuments(string operation)
        {
            var tupleList = new List<Tuple<string, string>>();
            var GivenTitle = "";

            if (operation != null && operation.Equals("Delete"))
            {
                DeleteText(Request.Form["titleLoad"]);
                return RedirectToAction("MyDocuments");
            }

            if (operation != null && operation.Equals("Search"))
            {
                GivenTitle = Request.Form["givenTitle"].ToString();
                using (var db = new FluidWriteContext())
                {
                    var docs =
                    (from Document in db.Documents
                     where Document.Doc_title.ToLower().Contains(GivenTitle.ToLower())
                     select Document);

                    var files = docs.ToList();
                    if (files.Count() == 0) { }
                    else
                    {
                        foreach (Document file in files)
                        {
                            try
                            {
                                using (System.IO.StreamReader sr = System.IO.File.OpenText(Dir + file.Doc_name))
                                {
                                    string s = "";
                                    string text = "";
                                    while ((s = sr.ReadLine()) != null)
                                    {
                                        text += s + '\n';
                                    }
                                    if (text.Length < 20)
                                    {
                                        tupleList.Add(Tuple.Create(file.Doc_title, text));
                                    }
                                    else
                                    {
                                        tupleList.Add(Tuple.Create(file.Doc_title, text.Substring(0, 20) + "..."));
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                Console.Write("");
                            }
                        }
                    }
                }
            }
            else
            {
                using (var db = new FluidWriteContext())
                {
                    var files = db.Documents;
                    if (files.Count() == 0) { }

                    else
                    {
                        foreach (Document file in files)
                        {
                            try
                            {
                                using (System.IO.StreamReader sr = System.IO.File.OpenText(Dir + file.Doc_name))
                                {
                                    string s = "";
                                    string text = "";
                                    while ((s = sr.ReadLine()) != null)
                                    {
                                        text += s + '\n';
                                    }
                                    if (text.Length < 20)
                                    {
                                        tupleList.Add(Tuple.Create(file.Doc_title, text));
                                    }
                                    else
                                    {
                                        tupleList.Add(Tuple.Create(file.Doc_title, text.Substring(0, 20) + "..."));
                                    }
                                }
                            }
                            catch (Exception)
                            {
                                Console.Write("");
                            }
                        }
                    }
                }
            }
            ViewData["GivenTitle"] = GivenTitle;
            tupleList.Sort((x, y) => string.Compare(x.Item1, y.Item1, StringComparison.CurrentCulture));
            ViewBag.List = tupleList;
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public void saveText(string title, string text)
        {
            using (var db = new FluidWriteContext())
            {
                if(db.Users.Count() == 0)
                {
                    db.Users.Add(new User { User_name = "user0", User_password = "user0", Email = "user0@gmail.com", Phone = "962323456" });
                    db.SaveChanges();
                }

            }

            DeleteText(title);

            string filename = Guid.NewGuid().GetHashCode()+ ".txt";

            using (var db = new FluidWriteContext())
            {
                db.Documents.Add(new Document { Doc_title = title, Doc_name = filename, User_id = db.Users.First().Id, User = db.Users.First() });
                db.SaveChanges();
            }

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (System.IO.File.Exists(Dir + filename))
                {
                    System.IO.File.Delete(Dir + filename);
                }

                // Create a new file     
                using (System.IO.FileStream fs = System.IO.File.Create(Dir + filename))
                {
                    // Add some text to file    
                    Byte[] textByte = new System.Text.UTF8Encoding(true).GetBytes(text);
                    fs.Write(textByte, 0, textByte.Length);
                }
            }
            catch (Exception)
            {
                TempData["Alert"] = "Error while saving file.";
            }
            TempData["Text"] = text;
            TempData["Title"] = title;

            TempData["WasSaved"] = "Your file was saved correctly.";
        }

        public void DeleteText(string title)
        {

            using (var db = new FluidWriteContext())
            {
                var docs =
                    (from Document in db.Documents
                     where Document.Doc_title.Equals(title)
                     select Document);

                if (docs.Count() != 0)
                {
                    var doc = docs.First();
                    System.IO.File.Delete(Dir + doc.Doc_name);
                    db.Documents.Remove(doc);
                    db.SaveChanges();
                }
            }

        }

        public void loadText(string title)
        {

            string filename;
            using (var db = new FluidWriteContext())
            {
                var name =
                    (from Document in db.Documents
                     where Document.Doc_title.Equals(title)
                     select Document.Doc_name);
                if (name.Count() != 0)
                    filename = name.First();
                else
                {
                    TempData["Alert"] = "This file does not exist.";
                    return;
                }

            }
            // Open the stream and read it back.  
            try
            {
                using (System.IO.StreamReader sr = System.IO.File.OpenText(Dir + filename))
                {
                    string s = "";
                    string text = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        text += s + '\n';
                    }
                    TempData["Text"] = text;
                }
                TempData["Title"] = Request.Form["titleLoad"].ToString();
            }catch(Exception)
            {
                TempData["Alert"] = "This file does not exist.";
            }
        }

        public IActionResult documentView(string operation)
        {
            if (!System.IO.Directory.Exists(Dir))
                System.IO.Directory.CreateDirectory(Dir);

            switch (operation)
            {
                case "Save":
                    saveText(Request.Form["title"].ToString(), Request.Form["text"].ToString());
                    return RedirectToAction("documentView");
                case "Load":
                    loadText(Request.Form["titleLoad"].ToString());
                    return RedirectToAction("documentView");
                default:
                    break;
            }
            
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
