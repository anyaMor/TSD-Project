﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FluidWrite.Models;
using Oracle.ManagedDataAccess.Client;

namespace FluidWrite.Controllers
{
    public class HomeController : Controller
    {
        const string Dir = "../FluidWriteFiles/";

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public void saveText()
        {

            string filename = Request.Form["title"] + ".txt";

            //string conString = "User Id = system; password = oracle; Data Source = localhost:1521/orcl";

            //using (OracleConnection conn = new OracleConnection(conString))
            //{
            //    int number = 0;
            //    using (OracleCommand cmd = conn.CreateCommand())

            //    {
            //        try

            //        {
            //            conn.Open();
            //            cmd.BindByName = true;
            //            cmd.CommandText = "Select Count(doc_id) from documentsFW";
            //            OracleDataReader reader = cmd.ExecuteReader();
            //            number = reader.GetInt32(0);

            //            reader.Dispose();
            //        }

            //        catch (Exception e)
            //        {
            //            Write(e.Message);
            //        }
            //    }
            //    using (OracleCommand cmd = conn.CreateCommand())
            //    {
            //        try
            //        {
            //            conn.Open();
            //            cmd.BindByName = true;

            //            cmd.CommandText = $"Insert into documentsFW(doc_id, doc_name, user_id, title) values ({number}, '{filename}', 0, '{Request.Form["title"]}'";
            //            OracleDataReader reader = cmd.ExecuteReader();

            //            reader.Dispose();
            //        }

            //        catch (Exception e)
            //        {
            //            Write(e.Message);
            //        }
            //    }
            //}

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (System.IO.File.Exists(Dir + filename))
                {
                    System.IO.File.Delete(Dir + filename);
                }

                // Create a new file     
                using (System.IO.FileStream fs = System.IO.File.Create(Dir + filename))
                {
                    // Add some text to file    
                    Byte[] text = new System.Text.UTF8Encoding(true).GetBytes(Request.Form["text"]);
                    fs.Write(text, 0, text.Length);
                }
            }
            catch (Exception Ex)
            {
                Console.WriteLine(Ex);
            }
            TempData["Text"] = Request.Form["text"].ToString();
            TempData["Title"] = Request.Form["title"].ToString();
        }

        public void loadText()
        {

            string filename = Request.Form["title"] + ".txt";
            // Open the stream and read it back.  
            try
            {
                using (System.IO.StreamReader sr = System.IO.File.OpenText(Dir + filename))
                {
                    string s = "";
                    string text = "";
                    while ((s = sr.ReadLine()) != null)
                    {
                        text += s + '\n';
                    }
                    TempData["Text"] = text;
                }
                TempData["Title"] = Request.Form["title"].ToString();
            }catch(Exception)
            {
                TempData["Alert"] = "This file does not exist.";
            }
        }

        public IActionResult documentView(string operation)
        {
            if (!System.IO.Directory.Exists(Dir))
                System.IO.Directory.CreateDirectory(Dir);

            switch (operation)
            {
                case "Save":
                    saveText();
                    return RedirectToAction("documentView");
                case "Load":
                    loadText();
                    return RedirectToAction("documentView");
                default:
                    break;
            }
            
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
