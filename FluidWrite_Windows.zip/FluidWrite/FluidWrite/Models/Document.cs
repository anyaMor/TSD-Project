﻿using System.ComponentModel.DataAnnotations;

namespace FluidWrite.Models
{

    public class Document
    {
        public int Id { get; set; }

        public string Doc_title { get; set; }
        public string Doc_name { get; set; }
        public int User_id { get; set; }
        public User User { get; set; }

    }
}